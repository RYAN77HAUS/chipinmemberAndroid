chipinMerchantApp.controller('merchantVerificationController', function($scope, $q, $http, $cookieStore, $location, $routeParams, apiSvc, $rootScope, $window,ngDialog){
     
    $scope.loggedInMerInfo = JSON.parse($window.localStorage["merLoggedInfo"]);
    loaderStat('show');

    $scope.makeTransaction = function(){
      loaderStat('show');
      var deferred = $q.defer();
      apiSvc.post(urls.transaction, {'memid':$routeParams.memberid, 'amount':$routeParams.amnt, 'username':$scope.loggedInMerInfo.uname})
      .then(function(result) {
          $scope.info = result;
          if( $scope.info.success )
          {   
            (function(alert) { // anonymous function redefining the "alert"
                alert($scope.info.error);
            })($rootScope.myFunkyAlert);
            $location.path('/thank-you');
          }
          else
          {
            (function(alert) { // anonymous function redefining the "alert"
                alert($scope.info.error);
            })($rootScope.myFunkyAlert);
            loaderStat('hide');
          }
      }, function(error) {
      deferred.reject(error);
      });
      return deferred.promise;    
    };

    if( $routeParams.memberid && $routeParams.payment && $routeParams.amnt && $routeParams.memberid != "undefined" && $routeParams.amnt != "undefined"  && $routeParams.amnt != "0" && $routeParams.payment == 2 )
    {

        $scope.verifyPin = function(pin){
            if( pin && pin != '' && typeof pin != "undefined" )
            {
                if( pin.length == 4)
                {
                    loaderStat('show');
                    var deferred = $q.defer();
                    apiSvc.post(urls.pinValidation, {'merid':$scope.loggedInMerInfo.merid, 'pin':pin})
                    .then(function(result) {
                        $scope.info = result;
                        if( $scope.info.success )
                        {   
                            $scope.makeTransaction();
                            loaderStat('hide');
                        }
                        else
                        {
                            (function(alert) { // anonymous function redefining the "alert"
                                alert($scope.info.error);
                            })($rootScope.myFunkyAlert);
                            loaderStat('hide');
                        }
                    }, function(error) {
                    deferred.reject(error);
                    });
                    return deferred.promise;    
                }
                
            }
        };

        $scope.scanQrcode = function() {
          cordova.plugins.barcodeScanner.scan(
            function (result) {
                console.log(result.text);
                qrScannedData = [];
                merIDArr = [];
                if( result && result != "" && result.cancelled != 1)
                {
                  if( result.format != "QR_CODE" )
                  {
                    (function(alert) { // anonymous function redefining the "alert"
                        alert("Please try to scan the QR code only!");
                    })($rootScope.myFunkyAlert);
                  }
                  else
                  {
                    if(result.text && result.text != "")
                    {
                      var qrScannedData = result.text.split(",");
                      if( qrScannedData && qrScannedData != "" && qrScannedData.length != 0)
                      {
                        var merIDArr = qrScannedData[0].split(":");
                        if( merIDArr && merIDArr != "" && merIDArr.length != 0)
                        {
                          if( merIDArr[0] == "Merchant ID" && merIDArr[1] && merIDArr[1] != "")
                          {
                            if( $scope.loggedInMerInfo.merid == merIDArr[1])
                            {
                              $scope.makeTransaction();
                            }
                            else
                            {
                              (function(alert) { // anonymous function redefining the "alert"
                                  alert("Merchant validation failed!");
                              })($rootScope.myFunkyAlert);
                            }
                          }
                          else
                          {
                            if( result.text.indexOf("B") == 0 )
                            {
                              if( $scope.loggedInMerInfo.merid == result.text )
                              {
                                $scope.makeTransaction();
                              }
                              else
                              {
                                (function(alert) { // anonymous function redefining the "alert"
                                    alert("Merchant validation failed!");
                                })($rootScope.myFunkyAlert);
                              }
                            }
                            else
                            {
                              (function(alert) { // anonymous function redefining the "alert"
                                alert("Scanning completed but merchant ID not found!");
                              })($rootScope.myFunkyAlert);
                            }                        
                          }
                        }
                      }
                      else
                      {
                        (function(alert) { // anonymous function redefining the "alert"
                          alert("Scanning failed. Please try again!");
                        })($rootScope.myFunkyAlert);
                      }
                    }
                    else
                    {
                      (function(alert) { // anonymous function redefining the "alert"
                          alert("Scanning failed. Please try again!");
                      })($rootScope.myFunkyAlert);
                    }
                  }
                }
                // alert("We got a barcode\n" +
                //       "Result: " + result.text + "\n" +
                //       "Format: " + result.format + "\n" +
                //       "Cancelled: " + result.cancelled);
            }, 
            function (error) {
                (function(alert) { // anonymous function redefining the "alert"
                    alert("Scanning failed. Please try again!");
                })($rootScope.myFunkyAlert);
            }
          );
        }
    }
    else
    {
        $location.path('/member-barcode-scan');
    }
    loaderStat('hide');
});