chipinMerchantApp.controller('merValidationController', function($scope, $q, $http, $cookieStore, $location, $routeParams, apiSvc, $rootScope, $window, ngDialog){
  
    $scope.loggedInMerInfo = JSON.parse($window.localStorage["merLoggedInfo"]);
     
    var qrScannedData = new Array();
    var memIDArr = new Array();
    loaderStat('show');



    $scope.registerMemberFinal = function(){
      loaderStat('show');
      var deferred = $q.defer();
      apiSvc.post(urls.registerMember, $rootScope.registerMemberData)
        .then(function(result) {
          //console.log(result);
          $scope.info = result;
          if( $scope.info.success )
          {   
              $rootScope.registerMemberData = {};   
                (function(alert) { // anonymous function redefining the "alert"
                  alert("Member has been registered successfully! PLease go to your email to confirm your Chipin Membership!");
              })($rootScope.myFunkyAlert);
              $location.path('/thank-you-member');
          }
          else
          {
              (function(alert) { // anonymous function redefining the "alert"
                  alert($scope.info.error);
              })($rootScope.myFunkyAlert);
              $location.path('/register-member');
          }
          loaderStat('hide');
        }, function(error) {
        deferred.reject(error);
        loaderStat('hide');
        });
        return deferred.promise;
    }

    $scope.skipScan = function(){
      $rootScope.registerMemberData.refid = $scope.loggedInMerInfo.merid;
      $scope.registerMemberFinal();
    }

    $scope.scanQrcode = function() {
      cordova.plugins.barcodeScanner.scan(
        function (result) {
            //console.log(result.text);
            qrScannedData = [];
            merIDArr = [];
            if( result && result != "" && result.cancelled != 1)
            {
              if( result.format != "QR_CODE" )
              {
                (function(alert) { // anonymous function redefining the "alert"
                    alert("Please try to scan the QR code only!");
                })($rootScope.myFunkyAlert);
              }
              else
              {
                if(result.text && result.text != "")
                {
                  console.log(result.text);
                  var qrScannedData = result.text.split(",");
                  if( qrScannedData && qrScannedData != "" && qrScannedData.length != 0)
                  {
                    var merIDArr = qrScannedData[0].split(":");
                    if( merIDArr && merIDArr != "" && merIDArr.length != 0)
                    {
                      if( merIDArr[0] == "Merchant ID" && merIDArr[1] && merIDArr[1] != "")
                      {
                        if( $scope.loggedInMerInfo.merid == merIDArr[1])
                        {
                          $rootScope.registerMemberData.refid = merIDArr[1];
                          $scope.registerMemberFinal();
                        }
                        else
                        {
                          (function(alert) { // anonymous function redefining the "alert"
                              alert("Merchant validation failed! The QR code you are trying to scan does not match with current logged in merchant!");
                          })($rootScope.myFunkyAlert);
                        }
                      }
                      else
                      {
                        if( result.text.indexOf("B") == 0 )
                        {
                          if( $scope.loggedInMerInfo.merid == result.text )
                          {
                            $rootScope.registerMemberData.refid = result.text;
                            $scope.registerMemberFinal();
                          }
                          else
                          {
                            (function(alert) { // anonymous function redefining the "alert"
                                alert("Merchant validation failed!");
                            })($rootScope.myFunkyAlert);
                          }
                        }
                        else
                        {
                          (function(alert) { // anonymous function redefining the "alert"
                            alert("Scanning completed but merchant ID not found!");
                          })($rootScope.myFunkyAlert);
                        }                        
                      }
                    }
                  }
                  else
                  {
                    (function(alert) { // anonymous function redefining the "alert"
                      alert("Scanning failed. Please try again!");
                    })($rootScope.myFunkyAlert);
                  }
                }
                else
                {
                  (function(alert) { // anonymous function redefining the "alert"
                      alert("Scanning failed. Please try again!");
                  })($rootScope.myFunkyAlert);
                }
              }
            }
            // alert("We got a barcode\n" +
            //       "Result: " + result.text + "\n" +
            //       "Format: " + result.format + "\n" +
            //       "Cancelled: " + result.cancelled);
        }, 
        function (error) {
            (function(alert) { // anonymous function redefining the "alert"
                alert("Scanning failed. Please try again!");
            })($rootScope.myFunkyAlert);
        }
      );
    }
  
    loaderStat('hide');
});