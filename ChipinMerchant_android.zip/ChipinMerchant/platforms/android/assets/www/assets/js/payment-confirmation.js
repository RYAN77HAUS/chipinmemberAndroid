chipinMerchantApp.controller('paymentConfirmationController', function($scope, $q, $http, $cookieStore, $location, $routeParams, apiSvc, $rootScope, $window,ngDialog){
 
    $scope.loggedInMerInfo = JSON.parse($window.localStorage["merLoggedInfo"]);
    $scope.appImageUrl = urls.appImagePath; 
    $scope.enableDisablePWC = true;
    $scope.preTaxAmnt = {};
    $scope.memberIdToShow = $routeParams.memberid;
    $scope.memberNameToShow = $routeParams.membername;
    $scope.amntValidateFlag = false;
    $scope.makeTransactionFlag = false;
    loaderStat('show');

    /*$scope.enablePayment = function(amnt){
        if( amnt && amnt != "" && amnt != 0 && typeof amnt != "undefined" && amnt != "NULL" && $scope.chipinBal != 0 )
        {
            if( amnt > $scope.chipinBal  )
            {
                $scope.enableDisablePWC = false;    
            }
            else
            {
                $scope.enableDisablePWC = true;
            }
        }
        else
        {
            $scope.enableDisablePWC = true;
        }
    }*/

    $scope.makeTransactionSbumit = function(){
       if($scope.makeTransactionFlag) 
       {
            $scope.makeTransaction();
            //console.log("Make transaction");
       }
       else
       {
            (function(alert) { // anonymous function redefining the "alert"
                alert("Amount or merchant verification failed");
            })($rootScope.myFunkyAlert);
       }
    }

    $scope.makeTransaction = function(){
       ngDialog.openConfirm({
            template:'\
                <p>Are you sure you want to make the transaction?</p>\
                <div class="ngdialog-buttons">\
                    <button type="button" class="btn btn-primary ngdialog-button ngdialog-button-secondary" ng-click="closeThisDialog(0)">Cancel</button>\
                    <button type="button" class="btn btn-primary ngdialog-button ngdialog-button-primary" ng-click="confirm(1)">Confirm</button>\
                </div>',
            plain: true
        }).then(function (confirm) {
            loaderStat('show');
           var deferred = $q.defer();
          apiSvc.post(urls.transaction, {'memid':$routeParams.memberid, 'amount':$scope.preTaxAmnt, 'username':$scope.loggedInMerInfo.uname})
          .then(function(result) {
              $scope.info = result;
              if( $scope.info.success )
              {   
                (function(alert) { // anonymous function redefining the "alert"
                    alert($scope.info.error);
                })($rootScope.myFunkyAlert);
                $location.path('/thank-you');
              }
              else
              {
                (function(alert) { // anonymous function redefining the "alert"
                    alert($scope.info.error);
                })($rootScope.myFunkyAlert);
                loaderStat('hide');
              }
          }, function(error) {
          deferred.reject(error);
          });
          return deferred.promise;  
        }, function(reject) {
            console.log("Transaction cancelled");
        });
      //console.log($routeParams.memberid+" "+$scope.preTaxAmnt+" "+$scope.loggedInMerInfo.uname);
        
    };

    $scope.verifyPin = function(pin){

        //console.log("Flag "+$scope.amntValidateFlag);
        if($scope.amntValidateFlag)
        {
            if( pin && pin != '' && typeof pin != "undefined" )
            {
                if( pin.length == 4)
                {
                    loaderStat('show');
                    var deferred = $q.defer();
                    apiSvc.post(urls.pinValidation, {'merid':$scope.loggedInMerInfo.merid, 'pin':pin})
                    .then(function(result) {
                        $scope.info = result;
                        if( $scope.info.success )
                        {   
                            loaderStat('hide');
                            //$scope.makeTransaction();
                            $scope.makeTransactionFlag = true;
                            
                        }
                        else
                        {
                            $scope.makeTransactionFlag = false;
                            (function(alert) { // anonymous function redefining the "alert"
                                alert($scope.info.error);
                            })($rootScope.myFunkyAlert);
                            loaderStat('hide');
                        }
                    }, function(error) {
                    deferred.reject(error);
                    });
                    return deferred.promise;    
                }
                
            }
        }
        else
        {
            $scope.makeTransactionFlag = false;
            /*setTimeout(function(){
                (function(alert) { // anonymous function redefining the "alert"
                    alert("Please enter amount!");
                })($rootScope.myFunkyAlert);
            },300);*/
        }
    };

    $scope.scanQrcode = function() {
      cordova.plugins.barcodeScanner.scan(
        function (result) {
            console.log(result.text);
            qrScannedData = [];
            merIDArr = [];
            if( result && result != "" && result.cancelled != 1)
            {
              if( result.format != "QR_CODE" )
              {
                (function(alert) { // anonymous function redefining the "alert"
                    alert("Please try to scan the QR code only!");
                })($rootScope.myFunkyAlert);
              }
              else
              {
                if(result.text && result.text != "")
                {
                  var qrScannedData = result.text.split(",");
                  if( qrScannedData && qrScannedData != "" && qrScannedData.length != 0)
                  {
                    var merIDArr = qrScannedData[0].split(":");
                    if( merIDArr && merIDArr != "" && merIDArr.length != 0)
                    {
                      if( merIDArr[0] == "Merchant ID" && merIDArr[1] && merIDArr[1] != "")
                      {
                        if( $scope.loggedInMerInfo.merid == merIDArr[1])
                        {
                          //$scope.makeTransaction();
                          $scope.makeTransactionFlag = true;
                        }
                        else
                        {
                          (function(alert) { // anonymous function redefining the "alert"
                              alert("Merchant validation failed!");
                          })($rootScope.myFunkyAlert);
                          $scope.makeTransactionFlag = false;
                        }
                      }
                      else
                      {
                        if( result.text.indexOf("B") == 0 )
                        {
                          if( $scope.loggedInMerInfo.merid == result.text )
                          {
                            //$scope.makeTransaction();
                            $scope.makeTransactionFlag = true;
                          }
                          else
                          {
                            $scope.makeTransactionFlag = false;
                            (function(alert) { // anonymous function redefining the "alert"
                                alert("Merchant validation failed!");
                            })($rootScope.myFunkyAlert);
                          }
                        }
                        else
                        {
                          (function(alert) { // anonymous function redefining the "alert"
                            alert("Scanning completed but merchant ID not found!");
                          })($rootScope.myFunkyAlert);
                          $scope.makeTransactionFlag = false;
                        }                        
                      }
                    }
                  }
                  else
                  {
                    (function(alert) { // anonymous function redefining the "alert"
                      alert("Scanning failed. Please try again!");
                    })($rootScope.myFunkyAlert);
                    $scope.makeTransactionFlag = false;
                  }
                }
                else
                {
                  (function(alert) { // anonymous function redefining the "alert"
                      alert("Scanning failed. Please try again!");
                  })($rootScope.myFunkyAlert);
                  $scope.makeTransactionFlag = false;
                }
              }
            }
            // alert("We got a barcode\n" +
            //       "Result: " + result.text + "\n" +
            //       "Format: " + result.format + "\n" +
            //       "Cancelled: " + result.cancelled);
        }, 
        function (error) {
            (function(alert) { // anonymous function redefining the "alert"
                alert("Scanning failed. Please try again!");
            })($rootScope.myFunkyAlert);
            $scope.makeTransactionFlag = false;
        }
      );
    }


    $scope.showMsgForBal = function(amnt){
        //console.log(typeof amnt);
        if( typeof amnt == "object" )
        {
            //var amntToCheck = Object.keys(amnt).length;    
             
            var amntToCheck = 0; 
             
        }
        else
        {
            var amntToCheck = amnt;    
        }
        /*if( $scope.enableDisablePWC )
        {
            (function(alert) { // anonymous function redefining the "alert"
                alert("Your chipin balance must be equal or greater than Amount!");
            })($rootScope.myFunkyAlert);
        }
        else
        {
            // 1 = pay with chipin balance | 2 = Payed with credit card or cash 
            $location.path('/merchant-verification/'+$routeParams.memberid+'/2');
        }*/

        if( amntToCheck && amntToCheck != "0" && amntToCheck != "undefined" )
        {
            //$location.path('/merchant-verification/'+$routeParams.memberid+'/'+amntToCheck+'/2');
            //console.log($routeParams.memberid+" "+amntToCheck);
            $scope.amntValidateFlag = true;
        }
        else
        {
            $scope.amntValidateFlag = false;
            /*setTimeout(function(){
                (function(alert) { // anonymous function redefining the "alert"
                    alert("Please enter amount!");
                })($rootScope.myFunkyAlert);
            },300);*/
            
        }
    }
    
    if( $routeParams.memberid && $routeParams.memberid != "" )
    {
        //console.log("Route Mem id "+$routeParams.memberid);
        var deferred = $q.defer();
        apiSvc.post(urls.memberAcntBal, {'memid':$routeParams.memberid})
        .then(function(result) {
            $scope.info = result;
            if( $scope.info.success )
            {   
                $scope.chipinBal = $scope.info.data.totalAccountBal.replace('$','');
                //console.log("Chipin bal "+$scope.chipinBal);
            }
            else
            {
                (function(alert) { // anonymous function redefining the "alert"
                    alert("Member id is invalid!");
                })($rootScope.myFunkyAlert);
            }
            loaderStat('hide');
        }, function(error) {
            deferred.reject(error);
            loaderStat('hide');
        });
        return deferred.promise;
        loaderStat('hide');
    }
    else
    {
        $location.path('/member-barcode-scan');
    }

 

    
     
    
});