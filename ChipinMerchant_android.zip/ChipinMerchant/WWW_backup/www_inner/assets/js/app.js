var chipinMerchantApp = angular.module('chipinMerchantApp', ['ngRoute','ngCookies','api','ngDialog']);

chipinMerchantApp.config(['$routeProvider', '$locationProvider',
  function($routeProvider,$locationProvider) {
   $routeProvider.
    when('/login', {
       templateUrl: 'views/login.html',
       controller: 'loginController'
   })
   .when('/register-member', {
       templateUrl: 'views/register-member.html',
       controller: 'registerMemberController'
   })
   .when('/merchant-barcode-scan', {
       templateUrl: 'views/merchant-barcode-scan.html',
       controller: 'merValidationController'
   })
   .when('/forget-password', {
       templateUrl: 'views/forget-password.html',
       controller: 'forgetPasswordController'
   })
   .when('/member-barcode-scan', {
       templateUrl: 'views/member-barcode-scan.html',
       controller: 'memBarcodeScanController'
   })
   .when('/payment-confirmation/:memberid', {
       templateUrl: 'views/payment-confirmation.html',
       controller: 'paymentConfirmationController'
   })
   .when('/merchant-verification/:memberid/:amnt/:payment', {
       templateUrl: 'views/merchant-verification.html',
       controller: 'merchantVerificationController'
   })
   .when('/thank-you', {
       templateUrl: 'views/thank-you.html',
       controller: 'thankYouController'
   })
   .when('/dashboard', {
       templateUrl: 'views/dashboard.html',
       controller: 'dashboardController'
   })
   .when('/logout', {
       templateUrl: 'views/logout.html',
       controller: 'logoutController'
   }).
   otherwise({
       redirectTo: '/login'
   })
  }]).run(function($rootScope,$window,validateStorage,ngDialog) { 
    loaderStat('show');
    $rootScope.$on('$viewContentLoaded', function(){
        //Here your view content is fully loaded !!
        //animateContainer();
    }); 
    
    $rootScope.$on('$routeChangeSuccess', function () {
        //console.log("test");  
        $( "html,body" ).scrollTop(0);
        validateStorage($rootScope);
    });

    /* new funky alert */
    $rootScope.myFunkyAlert = function(msg) {
        /* here goes your funky alert implementation */
        setTimeout(function(){
          $rootScope.alertMessage = msg;
            ngDialog.open({
                template: 'views/alert-popup.html',
                controller: "alertDialogCtrl",
            });
        },300);
    }

    $rootScope.goBackHistory = function() {
        history.back();
    }
    
    
}).factory('validateStorage', function( $cookieStore, $http, $location,$window){
    return function(scope) {
       //console.log("Path "+$location.path());

       if($window.localStorage["isMerLoggedIn"]) // If user is logged in redirect to Dashboard page
       {
           //console.log("Storage Set");
           if($location.path() == "/login")
           {
              $('.showMenuIfLogin').show();
              //console.log("Dashboard");
              $location.path('/dashboard');
           }
           else
           {
                $('.showMenuIfLogin').show();
           }
           
           // Do Something
       }
       else
       {
          if($location.path() == "/forget-password")
          {
             //console.log("foreget password");
          }
          else
          {
            //console.log("LOGIN");
            $('.showMenuIfLogin').hide();
            $location.path('/login');
          }  
          
       }
    }
}).directive('activeLink', ['$location', function (location) {
    return {
        restrict: 'A',
        link: function(scope, element, attrs, controller) {
            var clazz = attrs.activeLink;
            var path = attrs.href;
            path = path.substring(1); //hack because path does not return including hashbang
            scope.location = location;
            scope.$watch('location.path()', function (newPath) {
                if (path === newPath) {
                    element.addClass(clazz);
                } else {
                    element.removeClass(clazz);
                }
            });
        }
    };
}]);

// Show hide the loader
function loaderStat(stat){
    if(stat =='show'){ 
        $('.page-loader').show();
    }else{
        $('.page-loader').hide();
    }
} 

chipinMerchantApp.controller('logoutController', function($scope, $q, $http, $cookieStore, $location, $routeParams, apiSvc, $rootScope, $window){
    $window.localStorage["isMerLoggedIn"] = '';
    $window.localStorage["merLoggedInfo"] = '';
    $('.showMenuIfLogin').hide();
    $location.path('/login');
});

chipinMerchantApp.controller('thankYouController', function($scope, $q, $http, $cookieStore, $location, $routeParams, apiSvc, $rootScope, $window){
    $scope.appImageUrl = urls.appImagePath; 
});

chipinMerchantApp.controller('alertDialogCtrl', ["$scope", "$window", "$rootScope", "ngDialog", function($scope, $window, $rootScope, ngDialog) {
        $scope.msg = $rootScope.alertMessage;
}]);

chipinMerchantApp.directive('pwCheck', function() {
  return {
    require: 'ngModel',
    link: function (scope, elem, attrs, ctrl) {
        var firstPassword = '#' + attrs.pwCheck;
        elem.add(firstPassword).on('keyup', function () {
            scope.$apply(function () {
                // console.info(elem.val() === $(firstPassword).val());
                ctrl.$setValidity('pwmatch', elem.val() === $(firstPassword).val());
            });
        });
    }
  }
});

chipinMerchantApp.directive('onlyDigits', function () {
    return {
      require: 'ngModel',
      restrict: 'A',
      link: function (scope, element, attr, ctrl) {
        function inputValue(val) {
          if (val) {
            var digits = val.replace(/[^0-9]/g, '');

            if (digits !== val) {
              ctrl.$setViewValue(digits);
              ctrl.$render();
            }
            return parseInt(digits,10);
          }
          return undefined;
        }            
        ctrl.$parsers.push(inputValue);
      }
    };
});