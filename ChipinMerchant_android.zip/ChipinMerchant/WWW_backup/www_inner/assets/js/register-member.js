chipinMerchantApp.controller('registerMemberController', function($scope, $q, $http, $cookieStore, $location, $routeParams, apiSvc, $rootScope, $window,ngDialog){
    
    $scope.loggedInMemInfo = JSON.parse($window.localStorage["merLoggedInfo"]);
    $scope.merid = $scope.loggedInMemInfo.merid;   
    $scope.ageVerify = true; 
    $scope.passwordVerify = true;
    $scope.showLengthMsg = false;
    loaderStat('show');

    $scope.checkAge = function(dateofbirth){
    	
    	if( dateofbirth && dateofbirth != '' && dateofbirth != "undefined" && typeof dateofbirth != "undefined")
    	{
    		birthDate = new Date(dateofbirth);
    		givenDate = new Date();

		    $scope.tempyears = (givenDate.getFullYear() - birthDate.getFullYear());
		     
		    if (givenDate.getMonth() < birthDate.getMonth() ||
		     givenDate.getMonth() == birthDate.getMonth() && givenDate.getDate() < birthDate.getDate()) {
		            $scope.tempyears--;
		    }
            if( $scope.tempyears < 18 )
            {
                $scope.ageVerify = true;
                (function(alert) { // anonymous function redefining the "alert"
                    alert("You are not allowed to register. The minimum age is 18!");
                })($rootScope.myFunkyAlert);    
            }
		    else
            {
                $scope.ageVerify = false;
            }
		    //console.log($scope.tempyears);
    	}
    	else
    	{
            $scope.ageVerify = true;    
    	}
    }

    $scope.showLengthError = function(password){         
        if( password && typeof password != "undefined" )
        {
            if( password.length == 0 ||password.length >= 15 || password.length < 5 )
            {
                $scope.showLengthMsg = true;
                $scope.passwordVerify = true;
            }
            else
            {
                $scope.showLengthMsg = false;
                $scope.passwordVerify = false;
            }
        }
        else
        {
            $scope.passwordVerify = true;
        }
    }
     
    $scope.registerMember = function(fields){
    	loaderStat('show');
    	fields.action = "register";
        $rootScope.registerMemberData = fields;
        $location.path('/merchant-barcode-scan');
    	/*fields.refid = $scope.merid;
    	apiSvc.post(urls.registerMember, fields)
        .then(function(result) {
        	//console.log(result);
	        $scope.info = result;
	        if( $scope.info.success )
	        {   
	            fields = {};   
                (function(alert) { // anonymous function redefining the "alert"
	                alert("Member has been registered successfully!");
	            })($rootScope.myFunkyAlert);
	        }
	        else
	        {
	            (function(alert) { // anonymous function redefining the "alert"
	                alert($scope.info.error);
	            })($rootScope.myFunkyAlert);
	        }
	        loaderStat('hide');
        }, function(error) {
        deferred.reject(error);
        loaderStat('hide');
        });
        return deferred.promise;*/
    };
    
    setTimeout(function(){
        $('#Dob_tab2').datetimepicker({      
            format:'Y/m/d',
            timepicker:false
        });
    },1000);
    loaderStat('hide');
});