chipinMerchantApp.controller('dashboardController', function($scope, $q, $http, $cookieStore, $location, $routeParams, apiSvc, $rootScope, $window,ngDialog){
    $scope.title = "Dashboard";
    $scope.loggedInMemInfo = JSON.parse($window.localStorage["merLoggedInfo"]);
     
    loaderStat('show');
    loaderStat('hide');
});