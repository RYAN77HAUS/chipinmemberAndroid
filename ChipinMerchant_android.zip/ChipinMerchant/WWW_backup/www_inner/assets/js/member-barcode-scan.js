chipinMerchantApp.controller('memBarcodeScanController', function($scope, $q, $http, $cookieStore, $location, $routeParams, apiSvc, $rootScope, $window, ngDialog){
  
    $scope.loggedInMemInfo = JSON.parse($window.localStorage["merLoggedInfo"]);
    //console.log($scope.loggedInMemInfo);
    var qrScannedData = new Array();
    var memIDArr = new Array();
    loaderStat('show');

    $scope.authenticateM = function(parBy, parValue){
      loaderStat('show');
      var deferred = $q.defer();
      var tempPar = '';
      if( parBy && parBy == "userID" )
      {
        tempPar = {"checkType":"Member", "userID" : parValue};
      }
      else
      {
        tempPar = {"checkType":"Member", "phoneNo" : parValue};
      }
      apiSvc.post(urls.authenticateMemMer, tempPar)
      .then(function(result) {
          $scope.info = result;
          if( $scope.info.success )
          {     
            window.location.href = '#/payment-confirmation/'+$scope.info.data.memid;
          }
          else
          {
            (function(alert) { // anonymous function redefining the "alert"
              alert("Member validation failed!");
            })($rootScope.myFunkyAlert);
          }
          loaderStat('hide');
      }, function(error) {
      deferred.reject(error);
      loaderStat('hide');
      });
      return deferred.promise;
    }

    $scope.verifyMemID = function(id){
      if( id && id != "" )
      {
        $scope.authenticateM("userID",id);
      }
      else
      {
        (function(alert) { // anonymous function redefining the "alert"
          alert("Please enter Member ID!");
        })($rootScope.myFunkyAlert);
      }
    }

    $scope.verifyMemPH = function(phone){
      
      if( phone && phone != "" )
      {
        if ( /[a-zA-Z]/.test(phone) ) {
          (function(alert) { // anonymous function redefining the "alert"
            alert("Phone number must contain digit only!");
          })($rootScope.myFunkyAlert);
        }
        else if( phone.length != 10 )
        {
          (function(alert) { // anonymous function redefining the "alert"
            alert("Phone number must be of 10 digits!");
          })($rootScope.myFunkyAlert);
        }
        else
        {
          $scope.authenticateM("phoneNo",phone);
        }        
      }
      else
      {
        (function(alert) { // anonymous function redefining the "alert"
          alert("Please Enter Phone Number!");
        })($rootScope.myFunkyAlert);
      }
    }

    $scope.scanQrcode = function() {
      cordova.plugins.barcodeScanner.scan(
        function (result) {
            //console.log(result.text);
            qrScannedData = [];
            memIDArr = [];
            if( result && result != "" && result.cancelled != 1)
            {
              if( result.format != "QR_CODE" )
              {
                (function(alert) { // anonymous function redefining the "alert"
                    alert("Please try to scan the QR code only!");
                })($rootScope.myFunkyAlert);
              }
              else
              {
                if(result.text && result.text != "")
                {
                   
                  var qrScannedData = result.text.split(",");             
                  
                  if( qrScannedData && qrScannedData != "" && qrScannedData.length != 0)
                  {
                    var memIDArr = qrScannedData[0].split(":");
                    if( memIDArr && memIDArr != "" && memIDArr.length != 0)
                    {
                      if( memIDArr[0] == "Member ID" && memIDArr[1] && memIDArr[1] != "")
                      {
                        $scope.authenticateM("userID",memIDArr[1]);
                        //$location.path('/payment-confirmation/'+memIDArr[1]);
                      }
                      else
                      {
                        if( result.text.indexOf("Mbr") != -1 )
                        {
                          $scope.authenticateM("userID",result.text);
                        }
                        else
                        {
                          (function(alert) { // anonymous function redefining the "alert"
                            alert("Scanning Completed but Member ID not found!");
                          })($rootScope.myFunkyAlert);
                        }                        
                      }
                    }
                  }
                  else
                  {
                    (function(alert) { // anonymous function redefining the "alert"
                      alert("Scanning failed. Please try again!");
                    })($rootScope.myFunkyAlert);
                  }
                }
                else
                {
                  (function(alert) { // anonymous function redefining the "alert"
                      alert("Scanning failed. Please try again!");
                  })($rootScope.myFunkyAlert);
                }
              }
            }
            // alert("We got a barcode\n" +
            //       "Result: " + result.text + "\n" +
            //       "Format: " + result.format + "\n" +
            //       "Cancelled: " + result.cancelled);
        }, 
        function (error) {
            (function(alert) { // anonymous function redefining the "alert"
                alert("Scanning failed. Please try again!");
            })($rootScope.myFunkyAlert);
        }
      );
    }
  
    loaderStat('hide');
});