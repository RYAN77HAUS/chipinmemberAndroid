chipinMerchantApp.controller('paymentConfirmationController', function($scope, $q, $http, $cookieStore, $location, $routeParams, apiSvc, $rootScope, $window,ngDialog){
 
    $scope.loggedInMemInfo = JSON.parse($window.localStorage["merLoggedInfo"]);
    $scope.appImageUrl = urls.appImagePath; 
    $scope.enableDisablePWC = true;
    $scope.preTaxAmnt = {};
    loaderStat('show');

    /*$scope.enablePayment = function(amnt){
        if( amnt && amnt != "" && amnt != 0 && typeof amnt != "undefined" && amnt != "NULL" && $scope.chipinBal != 0 )
        {
            if( amnt > $scope.chipinBal  )
            {
                $scope.enableDisablePWC = false;    
            }
            else
            {
                $scope.enableDisablePWC = true;
            }
        }
        else
        {
            $scope.enableDisablePWC = true;
        }
    }*/

    $scope.showMsgForBal = function(amnt){
        //console.log(typeof amnt);
        if( typeof amnt == "object" )
        {
            //var amntToCheck = Object.keys(amnt).length;    
            (function(alert) { // anonymous function redefining the "alert"
                alert("Please Enter Amount!");
            })($rootScope.myFunkyAlert);
            return false;
        }
        else
        {
            var amntToCheck = amnt;    
        }
        /*if( $scope.enableDisablePWC )
        {
            (function(alert) { // anonymous function redefining the "alert"
                alert("Your chipin balance must be equal or greater than Amount!");
            })($rootScope.myFunkyAlert);
        }
        else
        {
            // 1 = pay with chipin balance | 2 = Payed with credit card or cash 
            $location.path('/merchant-verification/'+$routeParams.memberid+'/2');
        }*/

        if( amntToCheck && amntToCheck != "0" && amntToCheck != "undefined" )
        {
            $location.path('/merchant-verification/'+$routeParams.memberid+'/'+amntToCheck+'/2');
        }
        else
        {
            (function(alert) { // anonymous function redefining the "alert"
                alert("Please Enter Amount!");
            })($rootScope.myFunkyAlert);
        }
    }
    
    if( $routeParams.memberid && $routeParams.memberid != "" )
    {
        //console.log("Route Mem id "+$routeParams.memberid);
        var deferred = $q.defer();
        apiSvc.post(urls.memberAcntBal, {'memid':$routeParams.memberid})
        .then(function(result) {
            $scope.info = result;
            if( $scope.info.success )
            {   
                $scope.chipinBal = $scope.info.data.totalAccountBal.replace('$','');
                //console.log("Chipin bal "+$scope.chipinBal);
            }
            else
            {
                (function(alert) { // anonymous function redefining the "alert"
                    alert("Member id is invalid!");
                })($rootScope.myFunkyAlert);
            }
            loaderStat('hide');
        }, function(error) {
            deferred.reject(error);
            loaderStat('hide');
        });
        return deferred.promise;
        loaderStat('hide');
    }
    else
    {
        $location.path('/member-barcode-scan');
    }
    
});